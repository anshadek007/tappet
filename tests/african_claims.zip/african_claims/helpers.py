from django.shortcuts import*
from django.utils.html import format_html
from django.http import JsonResponse
def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


def getActions(id):
    # id,
    #           first_name,
    #           last_name,
    #           username,
    #           email
    edit_html = f'''
    <button class="btn btn-primary btn-icon btn-sm"  onclick="edit_row('{id}')" data-id="{id}" id="edit">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
        </svg>
    </button>
'''
    actionBtn = format_html(edit_html)
    
    delete_html = f'''
    <button class="btn btn-danger btn-icon btn-sm" onclick="delete_row({id})" data-id="{id}" id="delete">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        </svg>
    </button>
'''
    actionBtn += format_html(delete_html)

    view_html = f'''
    <button class="btn btn-secondary btn-icon btn-sm ml-2" onclick="view_row({id})"  id="edit" style="margin-left: 7px;">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
        </svg>
    </button>
'''
    actionBtn += format_html(view_html)

    return actionBtn


def jsonResponseWithMessage(code,string=""):
    data = ''
    # created
    if code == 201:
        data =  {
        "status": "success",
       
        "error_code":201,
        "message": "Created Successfully"
        }
    # updated
    if code == 200:
        data =  {
        "status": "success",
        
        "error_code":200,
        "message": "Updated Successfully"
        }

    # deleted
    if code == 204:
        data =  {
        "status": "success",
        
        "error_code":200,
        "message": "Deleted successfully"
        }

     
    # bad request
    if code == 400:
        data =  {
        "status": "failed",
       
        "error_code":400,
        "message": "Bad Request"
        }
    # alreday taken
    if code == 403:
        data =  {
        "status": "failed",
        "error_code":403,
        "message": f"{string} Already Taken"
        }
    # something went wrong
    if code ==500:
       data =  {
        "status": "failed",
        
        "error_code":500,
        "message": "Something Went Wrong"
        }
    # unauthorized
    if code ==401:
       data =  {
        "status": "failed",
        
        "error_code":401,
        "message": "Unauthorized"
        }

    return JsonResponse(data)
def jsonResponseWithMessageAndData(code,data):

    if code == 200:
        data =  {
        "status": "success",
        "data": {
            data
        },
        "error_code":200,
        "message": ""
        }