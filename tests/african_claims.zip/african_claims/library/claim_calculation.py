from django.shortcuts import*

def calculate_insured(values,turnover,uninsured,net_profit):
    res = int(values) - int(turnover) - int(uninsured) - int(net_profit)
    return res

def calculate_addition_basis(net_profit,insured):
    res = int(net_profit) + int(insured)
    return res

def calculate_differnce_basis(turnover,unisured):
    res = int(turnover) - int(unisured)
    return res

def calculate_rate_of_gross_profit(addition_basis,turn_over):
    decimal_value = int(addition_basis)/int(turn_over)
    res = decimal_value * 100

    
    return  res

def calculate_project_gross_profit(project_revanue,rate_of_gross_profit):
    res  = int(project_revanue) - int(rate_of_gross_profit)
    return res

   