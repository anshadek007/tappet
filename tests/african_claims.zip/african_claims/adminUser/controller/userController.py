from django.shortcuts import*
from django.http import HttpResponse
from django.template import loader
from django.http import JsonResponse
from adminUser.models import User

from helpers import is_ajax,getActions,jsonResponseWithMessage,jsonResponseWithMessageAndData
import bcrypt
# Create your views here.

def index(request):
    if request.user.is_authenticated:
        return render(request, 'admin/user/user_list.html')
        # return render(request, 'admin/user/user_copy.html')
    else:
        return redirect('login')


def add_edit_user(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            id = int(request.POST.get('id'))
            if (id > 0):
                res = update_user(request,id)
                return res
            
            if is_ajax(request=request):
                email = request.POST.get('email')
                res = check_email_exists_or_not_ajax(email)

                if (res == True):
                    return jsonResponseWithMessage(403,'Email')

                user_name = request.POST.get('username')

                res = check_username_exists_or_not_ajax(user_name)

                if (res == True):
                    return jsonResponseWithMessage(403,'User Name')


                password = request.POST.get('password')
                salt = bcrypt.gensalt()
                hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
                user_obj = User(
                                    first_name = request.POST.get('first_name'),
                                    last_name = request.POST.get('last_name'),
                                    email = request.POST.get('email'),
                                    username  = request.POST.get('username'),
                                    password = hashed_password,
                                    user_type = request.POST.get('user_type'),
                                    status = 1,
        )
                user_obj.save()
            
                return jsonResponseWithMessage(201)
            else:
                # If it's a regular form submission, redirect or render a response
                return jsonResponseWithMessage(400)
        else:
            return jsonResponseWithMessage(400)
    else:
        return jsonResponseWithMessage(401)



       
def datatable_data(request):
    if request.user.is_authenticated:
        data = User.objects.all().order_by('-pk').values()  # Query your data
        data = list(data)
        for item in data:
            item['action'] = getActions(item['id'])

        return JsonResponse({'data': list(data)})
    else:
        return jsonResponseWithMessage(401)
        
def get_user_ajax(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            id = request.POST.get('id')
            data_obj = User.objects.filter(id=id).values()
            
            return JsonResponse({'data': list(data_obj)})
        else:
                return jsonResponseWithMessage(400)
    else:
        return jsonResponseWithMessage(401)



def update_user(request,id):
    if request.user.is_authenticated:

        if is_ajax(request=request):
            
            my_objects = User.objects.filter(id=id)
            my_objects.update(first_name = request.POST.get('first_name'),
                                last_name = request.POST.get('last_name'),
                                email = request.POST.get('email'),
                                username  = request.POST.get('username'),
                                user_type = request.POST.get('user_type'),
                                        )
            return jsonResponseWithMessage(200)
        else:
            
            return jsonResponseWithMessage(400)
    else:
        return jsonResponseWithMessage(401)



def delete_user_ajax(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            id = int(request.POST.get('id'))
            if request.method == 'POST':
                if is_ajax(request=request):
                    res = User.objects.filter(id = id).delete()
                    
            return jsonResponseWithMessage(204)
            
        else:
            return jsonResponseWithMessage(400)
    else:
        return jsonResponseWithMessage(401)





def check_email_exists_or_not_ajax(email):

   

    if User.objects.filter(email=email).exists():
        return True
    else:
        return False

    


def check_username_exists_or_not_ajax(username):
   
    if User.objects.filter(username=username).exists():
        return True
    else:
        return False

    



   
    

