from django.shortcuts import*
from django.http import HttpResponse
from django.template import loader
from django.http import JsonResponse
from adminUser.models import AccountDescription

from helpers import is_ajax,getActions,jsonResponseWithMessage,jsonResponseWithMessageAndData
import bcrypt
# Create your views here.

def index(request):
    if request.user.is_authenticated:
        return render(request, 'admin/accountDescription/list.html')
        # return render(request, 'admin/user/user_copy.html')
    else:
        return redirect('login')


def add_edit_account_description(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            id = int(request.POST.get('id'))
            if (id > 0):
                res = update_account_description(request,id)
                return res
            if is_ajax(request=request):
                user_obj = AccountDescription(
                                    title = request.POST.get('title'),
                                    status = 1,
        )
                user_obj.save()
                
                return jsonResponseWithMessage(201)
            else:
               
                return jsonResponseWithMessage(400)
        else:
            return jsonResponseWithMessage(400)
    else:
        return jsonResponseWithMessage(401)



    
def datatable_data(request):

    data = AccountDescription.objects.all().order_by('-pk').values() # Query your data
    data = list(data)
    
    for item in data:
         item['action'] = getActions(item['id'])
    
    return JsonResponse({'data': list(data)})



def get_account_description_ajax(request):
    id = request.POST.get('id')
    data_obj = AccountDescription.objects.filter(id=id).values()
    
    return JsonResponse({'data': list(data_obj)})



def update_account_description(request,id):

    my_objects = AccountDescription.objects.filter(id=id)
    my_objects.update(  title = request.POST.get('title'),
                                 )
    return jsonResponseWithMessage(200)



def delete_account_description_ajax(request):
    if request.user.is_authenticated:
        if is_ajax(request=request):

            id = int(request.POST.get('id'))
            if request.method == 'POST':
                if is_ajax(request=request):
                    res = AccountDescription.objects.filter(id = id).delete()
            return jsonResponseWithMessage(204)
        else:
            return jsonResponseWithMessage(400)
    else:
        return jsonResponseWithMessage(401) 

    




    



   
    

