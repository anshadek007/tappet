from django.http import HttpResponse
from django.template import loader
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect


# Create your views here.

# def index(request):
#     return render(request, 'auth/admin_login.html')


def index(request):
    error_message = ""
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
       
        if user is not None:
            login(request, user)
            return redirect('admin.dashboard')  # Redirect to a specific URL after successful login
        else:
            error_message = 'Invalid username or password.'
    return render(request, 'auth/admin_login.html', {'error_message': error_message})