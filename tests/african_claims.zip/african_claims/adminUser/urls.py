"""
URL configuration for african_claims project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls.static import static
from django.urls import path

from african_claims import settings
from django.contrib import admin
from django.urls import path , include
from .controller import loginController,dashboradController,userController,accountDescriptionController

urlpatterns = [
    path('login', loginController.index, name='admin.login'),
    path('dashboard', dashboradController.index, name='admin.dashboard'),
    path('user', userController.index, name='admin.user'),
    path('add-edit-user', userController.add_edit_user, name='admin.add_edit_user'),
    path('users-data/', userController.datatable_data, name='admin.datatable.users.data'),
    path('get-user-ajax',userController.get_user_ajax, name='admin.ajax.get.user.data'),
    path('delete-user-ajax',userController.delete_user_ajax, name='admin.ajax.delete.user'),
    # accountdescription url
    path('account-description', accountDescriptionController.index, name='admin.account.description'),
    path('add-edit-account-description', accountDescriptionController.add_edit_account_description, name='admin.add.edit.account.description'),
    path('account-description-data/', accountDescriptionController.datatable_data, name='admin.datatable.account.description.data'),
    path('get-account-description-ajax',accountDescriptionController.get_account_description_ajax, name='admin.ajax.get.account.description.data'),
    path('delete-account-description-ajax',accountDescriptionController.delete_account_description_ajax, name='admin.ajax.delete.account.description'),

    

    
]


