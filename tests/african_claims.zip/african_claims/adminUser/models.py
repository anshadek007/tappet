from django.db import models
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _

class AccountDescription(models.Model):
    title = models.CharField(max_length=100)
    status = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'account_description'
        ordering = ["-id"]
    
class User(AbstractUser):
    class user_types(models.TextChoices):
        ADMIN = 'ADMIN', _('admin')
        INSURED = 'INSURED', _('insured')
        BROKER = 'BROKER', _('broker')
        
    user_type = models.CharField(
            max_length=50,
            choices=user_types.choices,
            default=user_types.ADMIN,
        )
    status = models.BooleanField()

    class Meta:
        db_table = 'auth_user'
    # user_type = models.CharField(max_length=200, null=True)
   