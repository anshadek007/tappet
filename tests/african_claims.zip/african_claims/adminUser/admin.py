from django.contrib import admin
from .models import AccountDescription,User
from django.contrib.auth.admin import UserAdmin

@admin.register(AccountDescription)
class RequestDemoAdmin(admin.ModelAdmin):
  list_display = [field.name for field in
AccountDescription._meta.get_fields()]
  
# admin.site.register(User)
# class RequestDemoAdmin(admin.ModelAdmin):
#   list_display = [field.name for field in
# User._meta.get_fields()]

class EmployeeAdmin(UserAdmin):
    pass

admin.site.register(User, EmployeeAdmin)