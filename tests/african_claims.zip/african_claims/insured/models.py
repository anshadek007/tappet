from django.db import models
from adminUser.models import User

# Create your models here.
class UserAccountDescription(models.Model):
    account_description = models.CharField(max_length=100)
    values = models.FloatField(default=0)
    turnover = models.FloatField(default=0)
    uninsured = models.FloatField(default=0)
    net_profit = models.FloatField(default=0)
    insured = models.FloatField(default=0)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'user_account_description'

class MasterUserAccountDescription(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    projected_revenue = models.FloatField(default=0)
    projected_gross_profit = models.FloatField(default=0)
    indemnity_period_in_months = models.FloatField(default=0)
    sum_insured_excluding_vat = models.FloatField(default=0)
    section_8_vat= models.FloatField(default=0)
    sum_insured = models.FloatField(default=0)
    additional_increased_cost_of_working = models.IntegerField(default=0)
    status = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'master_user_account_description'
