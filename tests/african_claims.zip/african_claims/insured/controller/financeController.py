from django.shortcuts import*
from django.http import HttpResponse
from django.template import loader
import library.claim_calculation as claim_calculation
from adminUser.models import AccountDescription
from insured.models import UserAccountDescription,MasterUserAccountDescription
from django.db.models import Sum
# Create your views here.

def index(request):
  
    if request.user.is_authenticated:
        user_id = request.user.id
        user_account_array = UserAccountDescription.objects.filter(user_id=user_id)
        
      
        if len(user_account_array) > 0:
            
            return redirect('insured.finance_list')
        else:
           
            account_description = AccountDescription.objects.all()
            array_count = len(account_description)
        
            return render(request, 'insured/finance.html', {'account_description': account_description,
                                                        "array_count" : array_count})
    else:
        return redirect('insured.login')
    
def add_finance(request):
    if request.user.is_authenticated:
        user_id = request.user.id
        user_count = request.POST['array_count']
        account_description_array = request.POST.getlist('account_description[]')
        values_array = request.POST.getlist('values[]')
        turnover_array = request.POST.getlist('turnover[]')
        insured_array = request.POST.getlist('insured[]')
        uninsured = request.POST.getlist('uninsured[]')
        net_profit = request.POST.getlist('net_profit[]')
        values = range(int(user_count))
        for i in values:
            #calculate insured
            insured = claim_calculation.calculate_insured(values_array[i],
                                                      turnover_array[i], 
                                                      uninsured[i], 
                                                      net_profit[i]
                                                      )
            # end calculate insured
            UserAccountDescription_obj = UserAccountDescription(
            account_description = account_description_array[i], 
            values= values_array[i], 
            turnover= turnover_array[i], 
            uninsured= uninsured[i], 
            net_profit = net_profit[i],
            insured= insured, 
            user_id = user_id,
            status = 1
            )
            UserAccountDescription_obj.save()

            #========= add master data hear =====

    master_userAccount_description_obj = MasterUserAccountDescription(
                                 projected_revenue = request.POST.get('projected_revenue'),
                                 projected_gross_profit = request.POST.get('projected_gross_profit'),
                                 indemnity_period_in_months = request.POST.get('indemnity_period_in_months'),
                                 sum_insured_excluding_vat = request.POST.get('sum_insured_excluding_vat'),
                                 section_8_vat = request.POST.get('section_8_vat'),
                                 sum_insured = request.POST.get('sum_insured'),
                                 additional_increased_cost_of_working = request.POST.get('additional_increased_cost_of_working'),
                                 status = 1,
                                 user_id = user_id

    )
    master_userAccount_description_obj.save()
    
            
    return redirect('insured.finance_list')
    

def finance_list(request):
    if request.user.is_authenticated:
        account_description = UserAccountDescription.objects.all()
        master_user_Account_description = MasterUserAccountDescription.objects.first()
        # calculations in all fileds sums
        turnover_sum = account_description.aggregate(sum=Sum('turnover'))['sum'] or 0
        uninsured_sum = account_description.aggregate(sum=Sum('uninsured'))['sum'] or 0
        insured_sum = account_description.aggregate(sum=Sum('insured'))['sum'] or 0
        net_profit_sum = account_description.aggregate(sum=Sum('net_profit'))['sum'] or 0
        
        differnce_basis = claim_calculation.calculate_differnce_basis(turnover_sum,uninsured_sum)
        addition_basis = claim_calculation.calculate_addition_basis(net_profit_sum,insured_sum)
        rate_of_gross_profit = claim_calculation.calculate_rate_of_gross_profit(addition_basis,turnover_sum)

        field_sum = {
            "turnover_sum" : turnover_sum,
            "uninsured_sum" : uninsured_sum,
            "insured_sum" : insured_sum,
            "net_profit_sum" : net_profit_sum,
            "differnce_basis": differnce_basis,
            "addition_basis" : addition_basis,
            "rate_of_gross_profit":rate_of_gross_profit
        }

        return render(request, 'insured/finance_list.html', {
                                                            'account_description': account_description,
                                                            'master_user_Account_description' : master_user_Account_description,
                                                             "field_sum":field_sum
                                                             })
    else:
        return redirect('insured.finance_list')
      