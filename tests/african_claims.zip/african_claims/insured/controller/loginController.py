from django.http import HttpResponse
from django.template import loader
from django.contrib.auth import authenticate, login,logout

from django.shortcuts import render, redirect


# Create your views here.

# def index(request):
#     return render(request, 'auth/admin_login.html')

def index(request):
    error_message = ""
    if request.user.is_authenticated:
        return redirect('insured.index')
    
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        # check if username and password is correct
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Redirect to a success page.
            return redirect('insured.index')
        else:
            error_message = 'Invalid email or password.'
            
    return render(request, 'auth/insured_login.html', {'error_message': error_message})

def logout_view(request):
    logout(request)
    return redirect('insured.login') 

def profile(request):
    return render(request, 'profile.html')