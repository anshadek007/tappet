from django.urls import path

from . import views
from .controller import financeController,loginController

urlpatterns = [
    path('', financeController.index, name='insured.index'),
    path('add-finance', financeController.add_finance, name='insured.add_finance'),
    path('finance-list', financeController.finance_list, name='insured.finance_list'),
    path('login', loginController.index, name='insured.login'),
    path('profile', loginController.profile, name='insured.profile'),
    path('logout/', loginController.logout_view, name='insured.logout'),
]