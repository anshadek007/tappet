<!--Bottom content -->
<tr>
    <td>
        <table align="left"  cellpadding="0" cellspacing="0"  width="100%"  style="padding: 20px 10px; max-width:600px;border-spacing:0px;border-width:medium;border-style:none; color: #bababa; font-size: 12px;line-height:22px; text-align: center;">
            <tbody>
                <tr>
                    <td>Copyright © {{ date('Y') }} {{ config('app.name') }}, All rights reserved.</td>
                </tr>
                <tr>
                    <td>This is a list for people that are interested in {{ config('app.name') }}</td>
                </tr>
                <tr>
                    <td style="font-weight:bold;padding-top: 20px;">Our mailing address is:</td>
                </tr>
                <tr>
                    <td>{{ config('app.name') }}</td>
                </tr>
                <tr>
                    <td>Genesis</td>
                </tr>
                <tr>
                    <td>York, Yorkshire YO10 5DQ</td>
                </tr>
                <tr>
                    <td>United Kingdom</td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>