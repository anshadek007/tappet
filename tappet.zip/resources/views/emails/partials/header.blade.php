<!-- Logo and text -->
<tr style="border-spacing:0px">
    <td style="border-spacing:0px;padding-bottom: 20px">
        <table cellpadding="10" cellspacing="0"  width="100%" style="max-width:600px;border-spacing:0px;border-width:medium;border-style:none">
            <tbody>
                <tr>
                    <td style="margin: 0 auto;padding: 0;text-align: center;"><img class="logo" src="{{ env('APP_URL','http://127.0.0.1') }}/public/assets/images/logo.png" /></td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>